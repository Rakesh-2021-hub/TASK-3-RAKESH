import pandas as pd
import sqlite3

conn = sqlite3.connect("data.db")

print("\n===== DATASET COLUMNS =====")

columns = pd.read_sql(
    "PRAGMA table_info(sales_data)",
    conn
)

print(columns)

print("\n===== SAMPLE DATA =====")

sample = pd.read_sql(
    "SELECT * FROM sales_data LIMIT 5",
    conn
)

print(sample)

print("\n===== TOTAL RECORDS =====")

total = pd.read_sql(
    """
    SELECT COUNT(*) AS Total_Records
    FROM sales_data
    """,
    conn
)

print(total)

# Find numeric columns automatically
df = pd.read_sql(
    "SELECT * FROM sales_data",
    conn
)

numeric_cols = df.select_dtypes(
    include=["int64", "float64"]
).columns

print("\n===== NUMERIC COLUMNS =====")
print(numeric_cols)

for col in numeric_cols:

    print(f"\n===== ANALYSIS OF {col} =====")

    query = f"""
    SELECT
        COUNT({col}) AS Count,
        AVG({col}) AS Average,
        MIN({col}) AS Minimum,
        MAX({col}) AS Maximum,
        SUM({col}) AS Total
    FROM sales_data
    """

    result = pd.read_sql(query, conn)

    print(result)

with open(
    "analysis_output.txt",
    "w",
    encoding="utf-8"
) as file:

    file.write("SQL Analysis Completed Successfully")

conn.close()

print("\nAnalysis Completed Successfully!")