import pandas as pd
import sqlite3

file_path = "Dataset for Data Analytics.xlsx"

df = pd.read_excel(file_path)

print("Columns Found:")
print(df.columns.tolist())

conn = sqlite3.connect("data.db")

df.to_sql(
    "sales_data",
    conn,
    if_exists="replace",
    index=False
)

conn.close()

print("Database Created Successfully!")